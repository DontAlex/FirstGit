from django.contrib import admin

# Register your models here.
from women.models import *

admin.site.register(Women)